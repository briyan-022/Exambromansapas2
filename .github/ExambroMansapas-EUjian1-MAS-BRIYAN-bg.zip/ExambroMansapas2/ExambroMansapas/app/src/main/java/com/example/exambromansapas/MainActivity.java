package com.example.exambromansapas;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    // Ganti 3 URL di bawah dengan link Google Form/Google Classroom/website ujian kamu.
    private static final String E_UJIAN_1 = "https://sites.google.com/view/atsiphone/halaman-muka";
    private static final String E_UJIAN_2 = "https://forms.google.com/";
    private static final String E_UJIAN_3 = "https://forms.google.com/";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        immersive();
        setContentView(new HomeView(this));
    }

    private void immersive() {
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override public void onWindowFocusChanged(boolean has) {
        super.onWindowFocusChanged(has);
        if (has) immersive();
    }

    private void openExam(String url, String title) {
        WebView web = new WebView(this);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Force the webpage to use the actual Android phone viewport.
                view.evaluateJavascript(
                    "(function(){var m=document.querySelector('meta[name=\\\"viewport\\\"]');" +
                    "if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}" +
                    "m.content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';" +
                    "document.documentElement.style.width='100%';document.body.style.width='100%';})();",
                    null);
            }
        });
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        web.setInitialScale(0);
        web.loadUrl(url);
        setContentView(web);
        immersive();
    }

    @Override public void onBackPressed() {
        View v = findViewById(android.R.id.content);
        // Back from WebView: return to the home screen. Normal Android exit is still possible from home.
        setContentView(new HomeView(this));
        immersive();
    }

    static class HomeView extends View {
        Paint p=new Paint(3); Paint text=new Paint(3); float d; RectF r=new RectF(); Bitmap bg;
        String[] labels={"SCAN QRCODE","MASUK URL","INFO","DEFAULT MODE","E-UJIAN 1","E-UJIAN 2","E-UJIAN 3","LISENSI","DEVELOPER","WEB","KELUAR"};
        String[] icons={"▣","▤","♧","⚙","▤","▤","▤","▯","◉","◎","✕"};
        HomeView(Context c){super(c); d=getResources().getDisplayMetrics().density; text.setTypeface(Typeface.create("sans",Typeface.BOLD)); bg=BitmapFactory.decodeResource(getResources(), com.example.exambromansapas.R.drawable.mas_briyan_bg); setBackgroundColor(Color.WHITE);}
        float dp(float x){return x*d;}
        void round(Canvas c,float l,float t,float rr,float bb,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(dp(l),dp(t),dp(rr),dp(bb)),dp(rad),dp(rad),p);}
        void center(Canvas c,String s,float x,float y,float size,int color){text.setTextSize(dp(size));text.setColor(color);text.setTextAlign(Paint.Align.CENTER);c.drawText(s,dp(x),dp(y),text);}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth()/d;
            // The original design uses a 690dp virtual canvas. Scale it to the actual Android phone width.
            float scale = w / 690f;
            c.save();
            c.scale(scale, scale);
            // User-provided background image, cropped to fill the virtual phone canvas.
            if (bg != null) {
                float sx = 690f / bg.getWidth();
                float sy = 1265f / bg.getHeight();
                float s = Math.max(sx, sy);
                float bw = bg.getWidth() * s, bh = bg.getHeight() * s;
                float left = (690f - bw) / 2f, top = (1265f - bh) / 2f;
                c.drawBitmap(bg, null, new RectF(dp(left), dp(top), dp(left + bw), dp(top + bh)), p);
            }
            // White translucent veil keeps the interface readable over the photo.
            p.setColor(0x66FFFFFF); c.drawRect(0,0,dp(690),dp(1265),p);
            center(c,"☾",38,43,32,Color.YELLOW); text.setTextAlign(Paint.Align.LEFT);text.setTypeface(Typeface.DEFAULT_BOLD);
            text.setTextSize(dp(29)); text.setColor(Color.BLACK); c.drawText("Hallo,para pecundang",dp(8),dp(88),text);
            text.setTextSize(dp(17)); c.drawText("Nilai hanyalah angka, akan tetapi nilai",dp(8),dp(116),text); c.drawText("membuat orang tuamu bangga.",dp(8),dp(138),text);
            round(c,36,302,654,610,18,Color.WHITE); p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(0x22000000);c.drawRoundRect(new RectF(dp(36),dp(302),dp(654),dp(610)),dp(18),dp(18),p);p.setStyle(Paint.Style.FILL);
            int[] xs={32,198,363,527}; int[] ys={684,884,1084}; int idx=0;
            for(int row=0;row<3;row++){int count=row<2?4:3; float start=row<2?xs[0]:114; for(int col=0;col<count;col++){float x=row<2?xs[col]:start+col*165; button(c,x,ys[row],labels[idx],icons[idx]); idx++;}}
            center(c,"MAS BRIYAN",345,1265,22,Color.BLACK);
            c.restore();
        }
        void button(Canvas c,float x,float y,String label,String icon){round(c,x,y,x+133,y+133,28,Color.rgb(185,104,210));center(c,icon,x+66.5f,y+62,42,Color.BLACK);center(c,label,x+66.5f,y+153,15,Color.BLACK);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_UP){
                float screenW=getWidth()/d;
                float scale=screenW/690f;
                float x=e.getX()/d/scale,y=e.getY()/d/scale;
                if(y>=684&&y<=840){
                    int col=(int)((x-32)/165);
                    if(col>=0&&col<4){
                        if(col==0) Toast.makeText(getContext(),"QR scanner belum dihubungkan",Toast.LENGTH_SHORT).show();
                        else Toast.makeText(getContext(),labels[col]+" dipilih",Toast.LENGTH_SHORT).show();
                    }
                } else if(y>=884&&y<=1040){
                    int col=(int)((x-32)/165);
                    if(col>=0&&col<4){
                        if(col==0) ((MainActivity)getContext()).openExam(E_UJIAN_1,"E-UJIAN 1");
                        else if(col==1) ((MainActivity)getContext()).openExam(E_UJIAN_2,"E-UJIAN 2");
                        else if(col==2) ((MainActivity)getContext()).openExam(E_UJIAN_3,"E-UJIAN 3");
                        else Toast.makeText(getContext(),"Lisensi",Toast.LENGTH_SHORT).show();
                    }
                }
            }
            return true;
        }
    }
}
