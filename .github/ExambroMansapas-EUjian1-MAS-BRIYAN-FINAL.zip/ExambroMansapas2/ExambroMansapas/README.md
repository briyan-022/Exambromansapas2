# Exambro Mansapas

Proyek Android dengan tampilan dashboard dan Immersive Mode.

## Memasang link E-Ujian
Buka `MainActivity.java`, lalu ganti `E_UJIAN_1`, `E_UJIAN_2`, dan `E_UJIAN_3` dengan URL Google Form/website ujian.

Ketika tombol E-Ujian ditekan, halaman dibuka di dalam WebView. Immersive mode tetap aktif dan tombol kembali membawa ke halaman utama. Dari halaman utama pengguna tetap bisa keluar dari aplikasi secara normal.
