package com.example.exambromansapas;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.app.NotificationManager;
import android.provider.Settings;
import android.os.Build;

public class MainActivity extends Activity {
    private int previousInterruptionFilter = NotificationManager.INTERRUPTION_FILTER_ALL;
    private boolean dndChangedByApp = false;
    private boolean examActive = false;
    // Ganti 3 URL di bawah dengan link Google Form/Google Classroom/website ujian kamu.
    private static final String E_UJIAN_1 = "https://sites.google.com/view/atsiphone/halaman-muka";
    private static final String E_UJIAN_2 = "https://forms.google.com/";
    private static final String E_UJIAN_3 = "https://forms.google.com/";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        immersive();
        setContentView(new HomeView(this));
    }

    private void immersive() {
        if (examActive) {
            // Keep the real status bar visible (white), hide only the navigation bar.
            // The decorative black exam bar is drawn directly below the status bar.
            getWindow().setStatusBarColor(Color.WHITE);
            getWindow().setNavigationBarColor(Color.BLACK);
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } else {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override public void onWindowFocusChanged(boolean has) {
        super.onWindowFocusChanged(has);
        if (has) immersive();
    }

    private void enableExamDnd() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) {
            try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); }
            catch (Exception ignored) {}
            Toast.makeText(this, "Izinkan akses Jangan Ganggu untuk mematikan notifikasi saat ujian.", Toast.LENGTH_LONG).show();
            return;
        }
        previousInterruptionFilter = nm.getCurrentInterruptionFilter();
        try {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE);
            dndChangedByApp = true;
        } catch (SecurityException ignored) {}
    }

    private void restoreExamDnd() {
        if (!dndChangedByApp || Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm.isNotificationPolicyAccessGranted()) {
            try { nm.setInterruptionFilter(previousInterruptionFilter); } catch (SecurityException ignored) {}
        }
        dndChangedByApp = false;
    }

    @Override protected void onStop() {
        super.onStop();
        restoreExamDnd();
    }

    private void openExam(String url, String title) {
        examActive = true;
        enableExamDnd();
        WebView web = new WebView(this);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Force the webpage to use the actual Android phone viewport.
                view.evaluateJavascript(
                    "(function(){var m=document.querySelector('meta[name=\\\"viewport\\\"]');" +
                    "if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}" +
                    "m.content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';" +
                    "document.documentElement.style.width='100%';document.body.style.width='100%';})();",
                    null);
            }
        });
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        web.setInitialScale(0);

        // Keep the decorative top bar visible above the exam WebView.
        FrameLayout examRoot = new FrameLayout(this);
        examRoot.setBackgroundColor(Color.WHITE);

        int barHeight = (int)(32 * getResources().getDisplayMetrics().density);

        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT);
        webLp.topMargin = barHeight;
        examRoot.addView(web, webLp);

        ExamBarView examBar = new ExamBarView(this);
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, barHeight);
        barLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        examRoot.addView(examBar, barLp);
        examBar.setElevation(dpToPx(8));
        examBar.bringToFront();

        setContentView(examRoot);
        web.loadUrl(url);
        immersive();
    }

    private int dpToPx(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onBackPressed() {
        examActive = false;
        restoreExamDnd();
        View v = findViewById(android.R.id.content);
        // Back from WebView: return to the home screen. Normal Android exit is still possible from home.
        setContentView(new HomeView(this));
        immersive();
    }

    static class ExamBarView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float d;

        ExamBarView(Context c) {
            super(c);
            d = getResources().getDisplayMetrics().density;
            setBackgroundColor(Color.TRANSPARENT);
            postInvalidateDelayed(1000);
        }

        float dp(float v) { return v * d; }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth();
            float blackH = dp(32);

            // Real-time decorative clock and fixed 50% battery stay outside the black icon bar.
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(dp(22));
            p.setColor(Color.BLACK);
            p.setTextAlign(Paint.Align.LEFT);
            String now = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(new java.util.Date());
            c.drawText(now, dp(10), dp(22), p);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText("50%", w - dp(10), dp(22), p);

            // Black bar only behind the three center icons.
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.BLACK);
            float iconBarW = dp(150);
            float iconBarL = (w - iconBarW) / 2f;
            c.drawRoundRect(new RectF(iconBarL, 0, iconBarL + iconBarW, blackH), dp(10), dp(10), p);

            float cy = blackH / 2f;
            p.setColor(Color.WHITE);
            p.setStrokeWidth(dp(2.1f));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);

            // 1. Refresh icon (small decorative icon).
            p.setStyle(Paint.Style.STROKE);
            float x1 = w / 2f - dp(48);
            float r = dp(9f);
            c.drawArc(new RectF(x1-r, cy-r, x1+r, cy+r), 35, 285, false, p);
            p.setStyle(Paint.Style.FILL);
            Path refresh = new Path();
            refresh.moveTo(x1 + dp(8f), cy - dp(9f));
            refresh.lineTo(x1 + dp(2f), cy - dp(9f));
            refresh.lineTo(x1 + dp(8f), cy - dp(2.5f));
            refresh.close();
            c.drawPath(refresh, p);

            // 2. Fullscreen icon: ONE continuous diagonal shaft with arrowheads
            // at both ends, matching the user's reference (no box).
            float x2 = w / 2f;
            float half = dp(9.5f);
            float head = dp(4.2f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2.2f));
            c.drawLine(x2 - half, cy + half, x2 + half, cy - half, p);
            c.drawLine(x2 - half, cy + half, x2 - half + head, cy + half, p);
            c.drawLine(x2 - half, cy + half, x2 - half, cy + half - head, p);
            c.drawLine(x2 + half, cy - half, x2 + half - head, cy - half, p);
            c.drawLine(x2 + half, cy - half, x2 + half, cy - half + head, p);

            // 3. Exit/arrow icon (small decorative icon).
            float x3 = w / 2f + dp(48);
            p.setStrokeWidth(dp(2.2f));
            c.drawLine(x3-dp(9f), cy, x3+dp(9f), cy, p);
            c.drawLine(x3+dp(9f), cy, x3+dp(3.5f), cy-dp(4.5f), p);
            c.drawLine(x3+dp(9f), cy, x3+dp(3.5f), cy+dp(4.5f), p);

            postInvalidateDelayed(1000);
        }
    }

    static class HomeView extends View {
        Paint p=new Paint(3); Paint text=new Paint(3); float d; Bitmap bg, centerImage;
        String[] labels={"SCAN QRCODE","MASUK URL","INFO","DEFAULT MODE","E-UJIAN 1","E-UJIAN 2","E-UJIAN 3","LISENSI","DEVELOPER","WEB","KELUAR"};
        String[] icons={"⌾","☠","☠","☠","☠","☠","☠","☠","☠","☠","☠"};
        HomeView(Context c){
            super(c); d=getResources().getDisplayMetrics().density;
            text.setTypeface(Typeface.create("sans",Typeface.BOLD));
            bg=BitmapFactory.decodeResource(getResources(), com.example.exambromansapas.R.drawable.mas_briyan_bg);
            centerImage=BitmapFactory.decodeResource(getResources(), com.example.exambromansapas.R.drawable.center_image);
            setBackgroundColor(Color.WHITE);
        }
        float dp(float x){return x*d;}
        void round(Canvas c,float l,float t,float rr,float bb,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(dp(l),dp(t),dp(rr),dp(bb)),dp(rad),dp(rad),p);}
        void center(Canvas c,String s,float x,float y,float size,int color){text.setTextSize(dp(size));text.setColor(color);text.setTextAlign(Paint.Align.CENTER);c.drawText(s,dp(x),dp(y),text);}
        void left(Canvas c,String s,float x,float y,float size,int color){text.setTextSize(dp(size));text.setColor(color);text.setTextAlign(Paint.Align.LEFT);c.drawText(s,dp(x),dp(y),text);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth()/d;
            float scale=w/690f;
            c.save(); c.scale(scale,scale);

            // Background image supplied by the user.
            if (bg != null) {
                float sx=690f/bg.getWidth(), sy=1325f/bg.getHeight(), sc=Math.max(sx,sy);
                float bw=bg.getWidth()*sc, bh=bg.getHeight()*sc;
                float left=(690f-bw)/2f, top=(1325f-bh)/2f;
                c.drawBitmap(bg,null,new RectF(dp(left),dp(top),dp(left+bw),dp(top+bh)),p);
            }
            // Light veil so text and controls remain readable.
            p.setColor(0x55FFFFFF); p.setStyle(Paint.Style.FILL); c.drawRect(0,0,dp(690),dp(1325),p);

            // Fake status bar: white bar, real clock, fixed decorative 50% battery.
            p.setColor(Color.WHITE); c.drawRect(0,0,dp(690),dp(60),p);
            String now=new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(new java.util.Date());
            left(c,now,18,39,24,Color.BLACK);
            left(c,"50%",610,39,20,Color.BLACK);

            // Greeting area. No moon icon.
            left(c,"Hallo,para pecundang",18,116,29,Color.BLACK);
            left(c,"Nilai hanyalah angka, akan tetapi nilai",18,144,17,Color.BLACK);
            left(c,"membuat orang tuamu bangga.",18,166,17,Color.BLACK);

            // Central image card.
            round(c,36,300,654,585,18,Color.WHITE);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0x33000000);
            c.drawRoundRect(new RectF(dp(36),dp(300),dp(654),dp(585)),dp(18),dp(18),p); p.setStyle(Paint.Style.FILL);
            if(centerImage!=null){
                c.drawBitmap(centerImage,null,new RectF(dp(45),dp(365),dp(645),dp(520)),p);
            }

            int[] xs={32,198,363,527}; int[] ys={660,860,1060}; int idx=0;
            for(int row=0;row<3;row++){
                int count=row<2?4:3; float start=row<2?xs[0]:114;
                for(int col=0;col<count;col++){
                    float x=row<2?xs[col]:start+col*165;
                    button(c,x,ys[row],labels[idx],icons[idx]); idx++;
                }
            }
            center(c,"MAS BRIYAN",345,1245,22,Color.BLACK);
            c.restore();

            // Repaint the clock once per second while the home screen is visible.
            postInvalidateDelayed(1000);
        }
        void button(Canvas c,float x,float y,String label,String icon){
            round(c,x,y,x+133,y+133,28,Color.rgb(185,104,210));
            center(c,icon,x+66.5f,y+72,43,Color.BLACK);
            center(c,label,x+66.5f,y+153,15,Color.BLACK);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_UP){
                float screenW=getWidth()/d, scale=screenW/690f;
                float x=e.getX()/d/scale,y=e.getY()/d/scale;
                if(y>=660&&y<=816){
                    int col=(int)((x-32)/165);
                    if(col>=0&&col<4){
                        if(col==0) Toast.makeText(getContext(),"QR scanner belum dihubungkan",Toast.LENGTH_SHORT).show();
                        else Toast.makeText(getContext(),labels[col]+" dipilih",Toast.LENGTH_SHORT).show();
                    }
                } else if(y>=860&&y<=1016){
                    int col=(int)((x-32)/165);
                    if(col>=0&&col<4){
                        if(col==0) ((MainActivity)getContext()).openExam(E_UJIAN_1,"E-UJIAN 1");
                        else if(col==1) ((MainActivity)getContext()).openExam(E_UJIAN_2,"E-UJIAN 2");
                        else if(col==2) ((MainActivity)getContext()).openExam(E_UJIAN_3,"E-UJIAN 3");
                        else Toast.makeText(getContext(),"Lisensi",Toast.LENGTH_SHORT).show();
                    }
                }
            }
            return true;
        }
    }

}
